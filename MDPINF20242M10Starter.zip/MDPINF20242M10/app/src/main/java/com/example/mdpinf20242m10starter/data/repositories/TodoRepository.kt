package com.example.mdpinf20242m10starter.data.repositories

import com.example.mdpinf20242m10starter.data.Todo

interface TodoRepository {
    suspend fun getAll():List<Todo>
    suspend fun getById(id:String):Todo?
    suspend fun insert(content:String)
    suspend fun update(id:String, content:String, completed:Boolean)
    suspend fun delete(id:String)
    suspend fun sync()
}