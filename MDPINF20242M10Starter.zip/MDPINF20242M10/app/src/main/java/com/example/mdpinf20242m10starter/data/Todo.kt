package com.example.mdpinf20242m10starter.data

import android.os.Parcelable
import com.example.mdpinf20242m10starter.data.sources.local.TodoEntity
import com.example.mdpinf20242m10starter.data.sources.remote.TodoJson
import kotlinx.parcelize.Parcelize
import java.util.Date

@Parcelize
data class Todo(
    val id:String,
    var content:String,
    var completed:Boolean = false,
    val createdAt:Date = Date(),
    var updatedAt:Date = Date(),
    var deletedAt:Date? = null
): Parcelable {

    init{
        if(id.length != 10){
            throw IllegalArgumentException(
                "Todo id must be a 10 alphanumeric character string!")
        }
        for(i in id){
            if(!(i in '0'..'9' || i in 'a'..'z' || i in 'A'..'Z')){
                throw IllegalArgumentException(
                    "Todo id must be a 10 alphanumeric character string!")
            }
        }
        if(content.isEmpty()){
            throw IllegalArgumentException("Todo content must not be empty!")
        }
    }

    companion object{
        fun randomId():String{
            val allowedChars = ('A'..'Z') + ('a'..'z') + ('0'..'9')
            return (1..10)
                .map { allowedChars.random() }
                .joinToString("")
        }
        fun fromTodoEntity(t: TodoEntity) =
            Todo(t.id, t.content, t.completed,
                Date(t.createdAt), Date(t.updatedAt),
                if(t.deletedAt == null){
                    null
                } else {
                    Date(t.createdAt)
                })
        fun fromTodoJson(t:TodoJson) =
            Todo(t.id, t.content, t.completed,
                Date(t.createdAt), Date(t.updatedAt),
                if(t.deletedAt == null){
                    null
                } else {
                    Date(t.createdAt)
                })
    }
    fun toTodoEntity() = TodoEntity(
        id, content, completed,
        createdAt.time, updatedAt.time, deletedAt?.time
    )
    fun toTodoJson() = TodoJson(
        id, content, completed,
        createdAt.time, updatedAt.time, deletedAt?.time
    )
}