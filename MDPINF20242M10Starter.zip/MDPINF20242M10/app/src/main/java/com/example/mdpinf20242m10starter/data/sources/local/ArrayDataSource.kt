package com.example.mdpinf20242m10starter.data.sources.local

import com.example.mdpinf20242m10starter.data.Todo
import java.util.Date

object MockDB{
    val todos:ArrayList<Todo> = ArrayList()

    init {
        todos.add(Todo(Todo.randomId(), "Play new game", true))
        todos.add(Todo(Todo.randomId(), "Meet up with friends", true))
        todos.add(Todo(Todo.randomId(), "Study for test"))
        todos.add(Todo(Todo.randomId(), "Buy milk"))
        todos.add(Todo(Todo.randomId(), "Do homework"))
    }
}

class ArrayDataSource:LocalDataSource {
    override suspend fun getAll(): List<Todo> {
        return MockDB.todos.filter { it.deletedAt == null }.map { it.copy() }.toList()
    }
    override suspend fun getById(id: String): Todo? {
        return MockDB.todos.find { it.id == id }
    }
    override suspend fun insert(content: String):Todo {
        val todo = Todo(Todo.randomId(), content)
        MockDB.todos.add(todo)
        return todo
    }
    override suspend fun update(id: String, content: String, completed: Boolean):Todo {
        val todo = MockDB.todos.find { it.id == id }
        if(todo != null){
            todo.content = content
            todo.completed = completed
            todo.updatedAt = Date()
            return todo
        }
        throw IllegalArgumentException()
    }
    override suspend fun delete(id: String):Todo {
        val todo = MockDB.todos.find { it.id == id }
        if(todo != null){
            todo.deletedAt = Date()
            return todo
        }
        throw IllegalArgumentException()
    }

    override suspend fun getUnsynced(): List<Todo> {
        TODO("Not yet implemented")
    }

    override suspend fun sync(todos: List<Todo>) {
        TODO("Not yet implemented")
    }
}