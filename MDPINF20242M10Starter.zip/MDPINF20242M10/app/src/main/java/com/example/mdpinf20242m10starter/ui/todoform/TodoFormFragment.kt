package com.example.mdpinf20242m10starter.ui.todoform

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.mdpinf20242m10starter.R
import com.example.mdpinf20242m10starter.TodoViewModelFactory
import com.example.mdpinf20242m10starter.databinding.FragmentTodoFormBinding

class TodoFormFragment : Fragment() {
    lateinit var binding: FragmentTodoFormBinding
    val viewModel by viewModels<TodoFormViewModel>{ TodoViewModelFactory }
    val args by navArgs<TodoFormFragmentArgs>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentTodoFormBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.cancelBtnTodoform.setOnClickListener {
            findNavController().navigate(R.id.action_todoFormFragment_to_todosFragment)
        }
        if(args.todoId != ""){
            viewModel.setTodo(args.todoId)
        }
        viewModel.id.observe(viewLifecycleOwner){
            if(it != ""){
                binding.idEtTodoform.setText(it)
                binding.titleTvTodoform.text = "Update Todo"
                binding.putBtnTodoform.text = "Update"
            }
        }
        viewModel.content.observe(viewLifecycleOwner){
            binding.contentEtTodoform.setText(it)
        }
        binding.putBtnTodoform.setOnClickListener {
            try{
                val id = binding.idEtTodoform.text.toString()
                val content = binding.contentEtTodoform.text.toString()
                viewModel.putTodo(id, content)
                findNavController().navigate(R.id.action_todoFormFragment_to_todosFragment)
            }
            catch (ex:Exception){
                Toast.makeText(requireContext(), "Error!", Toast.LENGTH_SHORT).show()
                Log.e("viewModel error", ex.toString())
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = TodoFormFragment()
    }
}