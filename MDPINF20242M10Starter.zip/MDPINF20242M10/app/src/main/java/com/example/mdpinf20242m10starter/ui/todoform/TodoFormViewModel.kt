package com.example.mdpinf20242m10starter.ui.todoform

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mdpinf20242m10starter.data.repositories.TodoRepository
import kotlinx.coroutines.launch

class TodoFormViewModel(
    private val todoRepository: TodoRepository
):ViewModel() {
    private val _id = MutableLiveData<String>()
    private val _content = MutableLiveData<String>()
    private var completed = false
    val id:LiveData<String>
        get() = _id
    val content:LiveData<String>
        get() = _content

    fun setTodo(newId:String){
        viewModelScope.launch {
            val todo = todoRepository.getById(newId)
            if(todo != null){
                _id.value = newId
                _content.value = todo.content
                completed = todo.completed
            }
        }
    }

    fun putTodo(id:String, content:String){
        if(content == ""){
            throw IllegalArgumentException("Todo content must not be null!")
        }
        else{
            viewModelScope.launch {
                if(id == ""){
                    todoRepository.insert(content)
                }
                else{
                    todoRepository.update(id, content, completed)
                }
            }
        }
    }
}