package com.example.mdpinf20242m10starter.data.sources.remote

import com.example.mdpinf20242m10starter.data.Todo

interface RemoteDataSource {
    suspend fun put(todo:Todo):Todo
    suspend fun sync(todos:List<Todo>):List<Todo>
}