package com.example.mdpinf20242m10starter.data.sources.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface TodoDao {
    @Query("select * from todos where deletedAt is null order by createdAt desc")
    suspend fun getAll():List<TodoEntity>
    @Query("select * from todos where id=:id and deletedAt is null")
    suspend fun getById(id:String): TodoEntity?
    @Insert
    suspend fun insert(todo:TodoEntity)
    @Update
    suspend fun update(todo:TodoEntity)
    @Delete
    suspend fun delete(todo:TodoEntity)
    @Query("select * from todos")
    suspend fun getUnsynced() : List<TodoEntity>
    @Query("delete from todos")
    suspend fun deleteAll()
    @Insert
    suspend fun bulkInsert(todos:List<TodoEntity>)
}