package com.example.mdpinf20242m10starter.data.sources.remote

import com.squareup.moshi.JsonClass
import java.util.Date

@JsonClass(generateAdapter = true)
data class TodoJson(
    val id:String,
    var content:String,
    var completed:Boolean=false,
    val createdAt: Long = Date().time,
    var updatedAt: Long = Date().time,
    var deletedAt: Long?=null
)