package com.example.mdpinf20242m10starter.data.repositories

import com.example.mdpinf20242m10starter.data.Todo
import com.example.mdpinf20242m10starter.data.sources.local.LocalDataSource
import com.example.mdpinf20242m10starter.data.sources.remote.RemoteDataSource

class TodoDefaultRepository(
    private val localDataSource: LocalDataSource,
    private val remoteDataSource: RemoteDataSource
):TodoRepository {
    override suspend fun getAll(): List<Todo> {
        return localDataSource.getAll()
    }
    override suspend fun getById(id: String): Todo? {
        return localDataSource.getById(id)
    }
    override suspend fun insert(content: String) {
        localDataSource.insert(content)
    }
    override suspend fun update(id: String, content: String, completed: Boolean) {
        localDataSource.update(id, content, completed)
    }
    override suspend fun delete(id: String) {
        localDataSource.delete(id)
    }

    override suspend fun sync() {
        val clientTodos = localDataSource.getUnsynced()
        val serverTodos = remoteDataSource.sync(clientTodos)
        localDataSource.sync(serverTodos)
    }
}