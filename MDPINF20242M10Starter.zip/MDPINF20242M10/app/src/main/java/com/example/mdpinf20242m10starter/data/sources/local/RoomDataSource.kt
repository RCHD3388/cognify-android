package com.example.mdpinf20242m10starter.data.sources.local

import com.example.mdpinf20242m10starter.data.Todo
import java.util.Date

class RoomDataSource(
    private val db:AppDatabase
):LocalDataSource {
    override suspend fun getAll(): List<Todo> {
        return db.todoDao().getAll()
            .map { Todo.fromTodoEntity(it) }
    }

    override suspend fun getById(id: String): Todo? {
        val todo = db.todoDao().getById(id)
        if (todo != null) {
            return Todo.fromTodoEntity(todo)
        } else {
            return null
        }
    }
    override suspend fun insert(content: String): Todo {
        val todo = Todo(Todo.randomId(), content)
        db.todoDao().insert(todo.toTodoEntity())
        return todo
    }
    override suspend fun update(id: String, content: String, completed: Boolean): Todo {
        val todo = db.todoDao().getById(id)
        if (todo != null) {
            todo.content = content
            todo.completed = completed
            db.todoDao().update(todo)
            return Todo.fromTodoEntity(todo)
        }else{
            throw Exception("Todo not found")
        }
    }
    override suspend fun delete(id: String): Todo {
        val todo = db.todoDao().getById(id)
        if (todo != null) {
            todo.deletedAt = Date().time
            db.todoDao().delete(todo)
            return Todo.fromTodoEntity(todo)
        }else {
            throw Exception("Todo not found")
        }
    }

    override suspend fun getUnsynced(): List<Todo> {
        return db.todoDao().getUnsynced().map {
            Todo.fromTodoEntity(it)
        }
    }

    override suspend fun sync(todos: List<Todo>) {
        db.todoDao().deleteAll()
        db.todoDao().bulkInsert(todos.map { it.toTodoEntity() })
    }
}
