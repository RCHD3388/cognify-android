package com.example.mdpinf20242m10starter.data.sources.remote

import com.example.mdpinf20242m10starter.data.Todo

class RetrofitDataSource(
    private val retrofitService: WebService
):RemoteDataSource {
    override suspend fun put(todo: Todo):Todo {
        return Todo.fromTodoJson(
            retrofitService.putTodo(todo.id, todo.toTodoJson())
        )
    }
    override suspend fun sync(todos: List<Todo>): List<Todo> {
        return retrofitService.syncTodo(
            todos.map { it.toTodoJson() }
        ).map { Todo.fromTodoJson(it) }
    }
}