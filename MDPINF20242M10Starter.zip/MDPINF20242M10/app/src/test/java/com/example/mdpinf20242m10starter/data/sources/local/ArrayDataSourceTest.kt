package com.example.mdpinf20242m10starter.data.sources.local

import com.example.mdpinf20242m10starter.data.Todo
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*

import org.junit.Before
import org.junit.Test

class ArrayDataSourceTest {
    lateinit var arrayDataSource: ArrayDataSource
    @Before
    fun setUp() {
        MockDB.todos.clear()
        MockDB.todos.add(Todo("0000000000", "Test0"))
        MockDB.todos.add(Todo("1111111111", "Test1"))
        MockDB.todos.add(Todo("2222222222", "Test2"))
        arrayDataSource = ArrayDataSource()
    }

    @Test
    fun getAll() = runTest {
        val todos = arrayDataSource.getAll()
        assertTrue(todos.size == 3)
        assertTrue(todos[0].id == "0000000000")
        assertTrue(todos[0].content == "Test0")
        assertTrue(todos[1].id == "1111111111")
        assertTrue(todos[1].content == "Test1")
        assertTrue(todos[2].id == "2222222222")
        assertTrue(todos[2].content == "Test2")
    }

    @Test
    fun getById() = runTest {
        var todo = arrayDataSource.getById("0000000000")
//        assertTrue(todo?.id == "0000000000")
//        assertTrue(todo?.content == "Test0")
        assertTrue(todo == MockDB.todos[0])
        todo = arrayDataSource.getById("3333333333")
        assertNull(todo)
    }

    @Test
    fun insert() = runTest {
        arrayDataSource.insert("Insert test")
        var todos = arrayDataSource.getAll()
        assertTrue(todos.size == 4)
        assertTrue(todos[3].content == "Insert test")
    }
}