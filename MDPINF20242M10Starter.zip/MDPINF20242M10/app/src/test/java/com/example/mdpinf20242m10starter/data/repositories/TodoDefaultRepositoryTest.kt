package com.example.mdpinf20242m10starter.data.repositories

import com.example.mdpinf20242m10starter.data.Todo
import com.example.mdpinf20242m10starter.data.sources.local.ArrayDataSource
import com.example.mdpinf20242m10starter.data.sources.local.LocalDataSource
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.every
import io.mockk.mockk
import io.mockk.slot
import io.mockk.verify
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*

import org.junit.Before
import org.junit.Test

class TodoDefaultRepositoryTest {
    lateinit var todoDefaultRepository: TodoDefaultRepository
    lateinit var localDataSource: LocalDataSource
    lateinit var dummyStorage: MutableList<Todo>

    @Before
    fun setUp() {
        localDataSource = mockk<LocalDataSource>()
        todoDefaultRepository = TodoDefaultRepository(localDataSource)
        dummyStorage = mutableListOf(
            Todo("0000000000", "Test0"),
            Todo("1111111111", "Test1")
        )
    }

    @Test
    fun getAll() = runTest {
        coEvery { localDataSource.getAll() } returns dummyStorage.toList()

        val todos = todoDefaultRepository.getAll()
        assertTrue(dummyStorage.size == todos.size)
        for(i in 0..<dummyStorage.size){
            println(dummyStorage[i])
            println(todos[i])
            if(dummyStorage[i].id != todos[i].id
                || dummyStorage[i].content != todos[i].content){
                fail()
            }
        }

        coVerify { localDataSource.getAll() }
    }

    @Test
    fun getById() = runTest {
        val contentSlot = slot<String>()
        coEvery { localDataSource.getById(capture(contentSlot)) } answers {
            dummyStorage.find { it.id == contentSlot.captured }
        }

        var todo = todoDefaultRepository.getById("0000000000")
        assertTrue(todo == dummyStorage[0])
        todo = todoDefaultRepository.getById("xxxxxxxxxx")
        assertNull(todo)

        coVerify { localDataSource.getById("0000000000") }
        coVerify { localDataSource.getById("xxxxxxxxxx") }
    }

    @Test
    fun insert() = runTest {
        val contentSlot = slot<String>()
        coEvery { localDataSource.insert(capture(contentSlot)) } answers {
            dummyStorage.add(Todo("xxxxxxxxxx", contentSlot.captured))
        }
        val content = "Insert Test"
        todoDefaultRepository.insert(content)
        assertTrue(dummyStorage[2].content == content)
        coVerify { localDataSource.insert(content) }
    }
}