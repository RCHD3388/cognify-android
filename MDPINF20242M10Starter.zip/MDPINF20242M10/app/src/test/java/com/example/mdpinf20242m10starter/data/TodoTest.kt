package com.example.mdpinf20242m10starter.data

import org.junit.Assert.*

import org.junit.After
import org.junit.Before
import org.junit.Test
import java.util.Date

class TodoTest {
    @Test
    // terkadang nama function dibuat untuk mendeskripsikan apa yang dites
    fun `Todo datetime correct`(){
        val currentTime = Date().time
        val todo = Todo("aaaaaaaaaa", "Test")
        assertTrue((currentTime - todo.createdAt.time) <= 1000)
        assertTrue((currentTime - todo.updatedAt.time) <= 1000)
    }

    @Test
    fun `Todo generate 10 alphanumeric character ID`(){
        val id = Todo.randomId()
        assertTrue("ID length is not 10", id.length == 10)
        for(i in id){
            if(!(i in '0'..'9' || i in 'a'..'z' || i in 'A'..'Z')){
                fail("ID not alphanumeric")
            }
        }
    }

    @Test(expected = IllegalArgumentException::class)
    fun `Todo ID must be 10 characters`(){
        Todo("","Test todo")
    }

    @Test(expected = IllegalArgumentException::class)
    fun `Todo ID must be alphanumeric`(){
        Todo("123456789)","Test todo")
    }

    @Test(expected = IllegalArgumentException::class)
    fun `Todo content must not be empty`(){
        Todo("1234567890","")
    }
}