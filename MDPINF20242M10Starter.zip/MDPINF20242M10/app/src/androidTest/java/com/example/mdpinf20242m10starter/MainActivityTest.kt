package com.example.mdpinf20242m10starter

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.matcher.ViewMatchers.withId
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.filters.LargeTest
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
@LargeTest
class MainActivityTest {
    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)
    @Test
    fun showTodosFragmentFirst(){
        onView(withId(R.id.constraint_todos))
            .check(matches(isDisplayed()))
    }
    @Test
    fun navigateFromTodosToTodoForm(){
        onView(withId(R.id.add_btn_todos))
            .perform(click())
        onView(withId(R.id.constraint_todo_form))
            .check(matches(isDisplayed()))
    }
    @Test
    fun navigateFromTodoFormToTodos(){
        onView(withId(R.id.add_btn_todos))
            .perform(click())
        onView(withId(R.id.constraint_todo_form))
            .check(matches(isDisplayed()))
        onView(withId(R.id.cancel_btn_todoform))
            .perform(click())
        onView(withId(R.id.constraint_todos))
            .check(matches(isDisplayed()))
    }
}