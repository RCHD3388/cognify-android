package com.cognifyteam.cognifyapp.data.repository.impl

import com.cognifyteam.cognifyapp.data.local.dao.UserDao
import com.cognifyteam.cognifyapp.data.remote.api.UserService
import com.cognifyteam.cognifyapp.data.repository.UserRepository
import com.cognifyteam.cognifyapp.model.User

class UserRepositoryImpl(
    private val userDao: UserDao,
    private val userService: UserService
) : UserRepository {

    override suspend fun getUser(userId: String): Result<User> {
        val cachedUserEntity = userDao.getUser(userId).value

        return if (cachedUserEntity != null) {
            Result.success(cachedUserEntity.toDomain())
        } else {
            try {
                val userResponse = userService.getUser(userId).toDomain()
                val userEntity = userResponse.toEntity()
                userDao.register(userEntity)
                Result.success(userResponse)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    override suspend fun saveUser(user: User) {
        val userEntity = user.toEntity()
        userDao.register(userEntity)
    }
}