package com.cognifyteam.cognifyapp.data.remote.api
import retrofit2.http.Body
import retrofit2.http.POST
interface UserService {
    @POST("login")
    suspend fun login(@Body loginRequest: RequestLogin): LoginResponse

    @POST("register")
    suspend fun register(@Body registerRequest: RequestRegister): RegisterResponse

}