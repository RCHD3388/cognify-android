package com.cognifyteam.cognifyapp.data.local.dao

import androidx.lifecycle.LiveData
import androidx.room.Insert
import androidx.room.Query
import com.cognifyteam.cognifyapp.data.local.model.UserEntity

interface UserDao {


    @Insert()
    suspend fun register(user : UserEntity)

}