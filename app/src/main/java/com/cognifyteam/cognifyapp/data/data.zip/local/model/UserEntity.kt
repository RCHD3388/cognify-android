package com.cognifyteam.cognifyapp.data.local.model

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val firebaseId: Int,
    val email: String,
    val role: String
)